


<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <script>document.write(new Date().getFullYear())</script>
                © <?php echo e($ins_name); ?>.
            </div>
            <div class="col-sm-6">
                <div class="text-sm-end d-none d-sm-block">
                    
                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH E:\project_july_2022\htdocs\store_management_backend_2022_october\resources\views/backend/include/footer.blade.php ENDPATH**/ ?>