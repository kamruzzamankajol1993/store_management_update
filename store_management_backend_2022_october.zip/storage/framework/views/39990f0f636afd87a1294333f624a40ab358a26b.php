<?php
     $usr = Auth::guard('admin')->user();
 ?>
<div class="vertical-menu">

    <div data-simplebar class="h-100">

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <li class="menu-title" key="t-menu">Menu</li>

                <li class="<?php echo e(Route::is('admin.dashboard') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="waves-effect">
                        <i class="bx bx-home-circle"></i>
                        <span key="t-dashboard">Dashboards</span>
                    </a>
                </li>
                <?php if($usr->can('product_add') || $usr->can('product_view') ||  $usr->can('product_update') ||  $usr->can('product_update')): ?>
                <li class="menu-title" key="t-menu">Product</li>

                  <?php if($usr->can('category_add') || $usr->can('category_view') ||  $usr->can('category_update') ||  $usr->can('category_update')): ?>
                <li class="<?php echo e(Route::is('admin.category_information')  ? 'active' : ''); ?>">
                       <a href="<?php echo e(route('admin.category_information')); ?>">
                        <i class="bx bx-label"></i>
                        <span>Category</span>
                    </a>
                   </li>

               <?php endif; ?>


               <?php if($usr->can('product_add') || $usr->can('product_view') ||  $usr->can('product_update') ||  $usr->can('product_update')): ?>
               <li class="<?php echo e(Route::is('admin.product_information')  ? 'active' : ''); ?>">
                      <a href="<?php echo e(route('admin.product_information')); ?>">
                       <i class="bx bx-cart-alt"></i>
                       <span>Product</span>
                   </a>
                  </li>

              <?php endif; ?>
<?php endif; ?>

              <?php if($usr->can('rack_add') || $usr->can('rack_view') ||  $usr->can('rack_update') ||  $usr->can('rack_update')): ?>

                <li class="menu-title" key="t-menu">RACK & SUPPLIER</li>


                <?php if($usr->can('rack_add') || $usr->can('rack_view') ||  $usr->can('rack_update') ||  $usr->can('rack_update')): ?>
                <li class="<?php echo e(Route::is('admin.rack_information')  ? 'active' : ''); ?>">
                       <a href="<?php echo e(route('admin.rack_information')); ?>">
                        <i class="bx bx-building"></i>
                        <span>Rack</span>
                    </a>
                   </li>

               <?php endif; ?>



                <?php if($usr->can('supplier_add') || $usr->can('supplier_view') ||  $usr->can('supplier_update') ||  $usr->can('supplier_update')): ?>
                <li class="<?php echo e(Route::is('admin.supplier_information')  ? 'active' : ''); ?>">
                       <a href="<?php echo e(route('admin.supplier_information')); ?>">
                        <i class="bx bx-user-plus"></i>
                        <span>Supplier</span>
                    </a>
                   </li>

               <?php endif; ?>


               <li>
                <a href="javascript: void(0);" class="has-arrow waves-effect">
                    <i class="bx bxs-truck"></i>
                    <span key="t-projects">Request Product</span>
                </a>
                <ul class="sub-menu" aria-expanded="false">

                    <?php if($usr->can('request_product_add') || $usr->can('request_product_view') ||  $usr->can('request_product_update') ||  $usr->can('request_product_delete')): ?>
                    <li class="<?php echo e(Route::is('admin.request_product_information.create')   ? 'active' : ''); ?>">
                           <a href="<?php echo e(route('admin.request_product_information.create')); ?>"><span>Add Request Product</span> </a>
                       </li>

                   <?php endif; ?>

                   <?php if($usr->can('request_product_add') || $usr->can('request_product_view') ||  $usr->can('request_product_update') ||  $usr->can('request_product_delete')): ?>
                   <li class="<?php echo e(Route::is('admin.request_product_information')   ? 'active' : ''); ?>">
                          <a href="<?php echo e(route('admin.request_product_information')); ?>"><span>Request Product List</span> </a>
                      </li>

                  <?php endif; ?>


                </ul>
             </li>

<?php endif; ?>

               <?php if($usr->can('inventory_add') || $usr->can('inventory_view') ||  $usr->can('inventory_update') ||  $usr->can('inventory_delete')): ?>
                <li class="menu-title" key="t-menu">INVENTORY</li>


               <li>
                <a href="javascript: void(0);" class="has-arrow waves-effect">
                    <i class="bx bx-label"></i>
                    <span key="t-projects">Manage Inventory</span>
                </a>
                <ul class="sub-menu" aria-expanded="false">

                    <?php if($usr->can('inventory_add') || $usr->can('inventory_view') ||  $usr->can('inventory_update') ||  $usr->can('inventory_delete')): ?>
                    <li class="<?php echo e(Route::is('admin.inventory_information.create')   ? 'active' : ''); ?>">
                           <a href="<?php echo e(route('admin.inventory_information.create')); ?>"><span>Add Inventory</span> </a>
                       </li>

                   <?php endif; ?>

                   <?php if($usr->can('inventory_add') || $usr->can('inventory_view') ||  $usr->can('inventory_update') ||  $usr->can('inventory_delete')): ?>
                   <li class="<?php echo e(Route::is('admin.inventory_information')   ? 'active' : ''); ?>">
                          <a href="<?php echo e(route('admin.inventory_information')); ?>"><span>Inventory List</span> </a>
                      </li>

                  <?php endif; ?>


                </ul>
             </li>
             <?php endif; ?>
             <li class="menu-title" key="t-menu">STAFF & PRODUCT REQUISITION</li>


             <?php if($usr->can('admin.create') || $usr->can('admin.view') ||  $usr->can('admin.edit') ||  $usr->can('admin.delete')): ?>
             <li class="<?php echo e(Route::is('admin.admins') || Route::is('admin.admins.create') || Route::is('admin.admins.edit') ? 'active' : ''); ?>">
                 <a href="<?php echo e(route('admin.admins')); ?>"><i class="bx bx-user"></i><span>Staff</span> </a>
             </li>

           <?php endif; ?>


           <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="bx bx-archive"></i>
                <span key="t-projects">Manage Requisition</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">

                <?php if($usr->can('requisition_add') || $usr->can('requisition_view') ||  $usr->can('requisition_update') ||  $usr->can('requisition_delete')): ?>
                <li class="<?php echo e(Route::is('admin.requisition_information.create')   ? 'active' : ''); ?>">
                       <a href="<?php echo e(route('admin.requisition_information.create')); ?>"><span>Add Requisition</span> </a>
                   </li>

               <?php endif; ?>

               <?php if($usr->can('requisition_add') || $usr->can('requisition_view') ||  $usr->can('requisition_update') ||  $usr->can('requisition_delete')): ?>
               <li class="<?php echo e(Route::is('admin.requisition_information')   ? 'active' : ''); ?>">
                      <a href="<?php echo e(route('admin.requisition_information')); ?>"><span>Requisition List</span> </a>
                  </li>

              <?php endif; ?>


            </ul>
         </li>
         <?php if($usr->can('system_information_add') || $usr->can('system_information_view') ||  $usr->can('system_information_update') ||  $usr->can('system_information_delete')): ?>
         <li class="menu-title" key="t-menu">OTHER</li>


                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bx-cog"></i>
                        <span key="t-projects">Setting</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <?php if($usr->can('system_information_add') || $usr->can('system_information_view') ||  $usr->can('system_information_update') ||  $usr->can('system_information_delete')): ?>
                        <li class="<?php echo e(Route::is('admin.system_information')  ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.system_information')); ?>"> <span>Company Information</span> </a></li>

            <?php endif; ?>




                   <?php if($usr->can('role.create') || $usr->can('role.view') ||  $usr->can('role.edit') ||  $usr->can('role.delete')): ?>
                        <li class="<?php echo e(Route::is('admin.roles') || Route::is('admin.roles.create') || Route::is('admin.roles.edit') ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.roles')); ?>"> <span>Role List</span> </a></li>

            <?php endif; ?>
                   <?php if($usr->can('permission.create') || $usr->can('permission.view') ||  $usr->can('permission.edit') ||  $usr->can('permission.delete')): ?>
                     <li class="<?php echo e(Route::is('admin.permission') || Route::is('admin.permission.create') || Route::is('admin.permission.edit') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.permission')); ?>"><span>Permission</span> </a>
                        </li>

                    <?php endif; ?>




                        
                    </ul>
                </li>
                <?php endif; ?>
            </ul>
        </div>
        <!-- Sidebar -->
    </div>
</div>








<?php /**PATH E:\project_july_2022\htdocs\store_management_backend_2022_october\resources\views/backend/include/sidebar.blade.php ENDPATH**/ ?>