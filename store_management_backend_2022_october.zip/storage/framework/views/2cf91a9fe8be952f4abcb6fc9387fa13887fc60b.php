<?php $__env->startSection('title'); ?>
Dashboard
<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0 font-size-18">Dashboard</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<div class="row">
    
    <div class="col-xl-12">
        <div class="row">
            <div class="col-sm-3">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex align-items-center mb-3">
                            <div class="avatar-xs me-3">
                                <span class="avatar-title rounded-circle bg-primary bg-soft text-primary font-size-18">
                                    <i class="bx bx-copy-alt"></i>
                                </span>
                            </div>
                            <h5 class="font-size-14 mb-0">TOTAL STAFF</h5>
                        </div>
                        <div class="text-muted mt-4">
                            <h4><?php echo e($count_admin); ?><i class="mdi mdi-chevron-up ms-1 text-success"></i></h4>
                            
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-3">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex align-items-center mb-3">
                            <div class="avatar-xs me-3">
                                <span class="avatar-title rounded-circle bg-primary bg-soft text-primary font-size-18">
                                    <i class="bx bx-copy-alt"></i>
                                </span>
                            </div>
                            <h5 class="font-size-14 mb-0">TOTAL PRODUCT REQUISITION</h5>
                        </div>
                        <div class="text-muted mt-4">
                            <h4><?php echo e($total_re_product); ?><i class="mdi mdi-chevron-up ms-1 text-success"></i></h4>
                            
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-3">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex align-items-center mb-3">
                            <div class="avatar-xs me-3">
                                <span class="avatar-title rounded-circle bg-primary bg-soft text-primary font-size-18">
                                    <i class="bx bx-archive-in"></i>
                                </span>
                            </div>
                            <h5 class="font-size-14 mb-0">DUE REQUISITION</h5>
                        </div>
                        <div class="text-muted mt-4">
                            <h4><?php echo e($total_re_due_product); ?><i class="mdi mdi-chevron-up ms-1 text-success"></i></h4>
                            
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-3">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex align-items-center mb-3">
                            <div class="avatar-xs me-3">
                                <span class="avatar-title rounded-circle bg-primary bg-soft text-primary font-size-18">
                                    <i class="bx bx-purchase-tag-alt"></i>
                                </span>
                            </div>
                            <h5 class="font-size-14 mb-0">TOTAL PRODUCT</h5>
                        </div>
                        <div class="text-muted mt-4">
                            <h4><?php echo e($total_product); ?> <i class="mdi mdi-chevron-up ms-1 text-success"></i></h4>

                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- end row -->
    </div>
</div>
<div class="row">
    <div class="col-xl-12">
        <div class="card">
            <div class="card-header">
                Due Requisition
            </div>
            <div class="card-body">


                <div class="table-responsive">
                    <table id="datatable-buttons" class="table table-bordered dt-responsive nowrap"
                    style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                                        <thead>
                                                            <tr>
                                                                <th>SL.</th>
                                                                <th>Staff Name(Position)</th>
                                                                <th>Product Name & Quantity</th>
                                                                <th>Request Type</th>
                                                                <th>Date</th>
                                                                <th>Request Status</th>
                                                                <th>Action</th>
                                                            </tr>
                                                        </thead>


                                                        <tbody>
                                                            <?php $__currentLoopData = $requisition_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                                <tr>
                                                   <td>


                                                    <?php echo e($loop->index+1); ?>





                                                </td>


                                                    <td>

                                                    <?php

                                                 $use_list_new = DB::table('admins')->where('id',$user->admin_id)->first();

                                                    ?>



                                                        <?php echo e($use_list_new->name); ?>(<?php echo e($use_list_new->position); ?>)


                                                    </td>


                                                    <td>

                                                        <?php

                                                     $product_name_quantity = DB::table('rproducts')->where('r_id',$user->id)->get();

                                                        ?>
                <?php $__currentLoopData = $product_name_quantity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_product_name_quantity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php



                $product_name = DB::table('products')
                ->where('id', $all_product_name_quantity->product_id )->value('name');


                                        ?>

                <?php echo e($product_name); ?>-<?php echo e($all_product_name_quantity->quantity); ?> <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                                                        </td>
                                                        <td><?php echo e($user->request_type); ?></td>

                                                        <td><?php echo e(date('d-m-Y', strtotime($user->request_date))); ?></td>

                                                    <td>
                                                     <?php echo e($user->status); ?>








                                                    </td>

                                                    <td>

                                                        <?php if($Auth::guard('admin')->user()->id == 1): ?>

                                                      <?php if(Auth::guard('admin')->user()->can('requisition_view')): ?>
                                                          <button type="button" data-bs-toggle="modal" data-bs-target=".bs-example-modal-lg<?php echo e($user->id); ?>"
                                                          class="btn btn-success waves-light waves-effect  btn-sm" >
                                                          <i class="fas fa-envelope"></i></button>

                                                            <!--  Large modal example -->
                                                            <div class="modal fade bs-example-modal-lg<?php echo e($user->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                                                <div class="modal-dialog modal-lg">
                                                                    <div class="modal-content">
                                                                        <div class="modal-header">
                                                                            <h5 class="modal-title" id="myLargeModalLabel">Product Requisition Status Change</h5>
                                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                                                                            </button>
                                                                        </div>
                                                                        <div class="modal-body">
                                                                            <form action="<?php echo e(route('admin.status_requisition_information.update')); ?>" method="POST" enctype="multipart/form-data">

                                                                                <?php echo csrf_field(); ?>


                                                                        <input type="hidden" class="form-control form-control-sm" id="name" name="id" placeholder="Enter Name" value="<?php echo e($user->id); ?>">
                                                                        <div class="row">

                                                                            <div class="form-group ">
                                                                                <label>Date:</label>
                                                                                <div class="input-group" id="datepicker2">
                                                                                    <input type="text" name="request_date" value="<?php echo e($user->request_date); ?>" class="form-control" placeholder="dd M, yyyy"
                                                                                           data-date-format="dd M, yyyy" data-date-container='#datepicker2'
                                                                                           data-provide="datepicker" data-date-autoclose="true">

                                                                                    <span class="input-group-text"><i class="mdi mdi-calendar"></i></span>
                                                                                </div>
                                                                            </div>

                                                                            <div class="form-group ">
                                                                                <label>Product Requisition Status</label>
                                                                                <select name="status" id="" class="form-control">
                                                                                    <option value="Accept" <?php echo e($user->status == 'Accept' ? 'selected':''); ?>>Accept</option>
                                                                                    <option value="Deny" <?php echo e($user->status == 'Deny' ? 'selected':''); ?>>Deny</option>
                                                                                </select>
                                                                            </div>








                                                                        </div>





                                                                                <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Update</button>
                                                                            </form>
                                                                        </div>
                                                                    </div><!-- /.modal-content -->
                                                                </div><!-- /.modal-dialog -->
                                                            </div><!-- /.modal -->


                <?php endif; ?>

                <?php else: ?>


                <?php endif; ?>

                





                                                    </td>
                                                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                        </tbody>
                                                    </table>
                </div>
            </div>
        </div>
    </div>


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project_july_2022\htdocs\store_management_backend_2022_october\resources\views/backend/index.blade.php ENDPATH**/ ?>