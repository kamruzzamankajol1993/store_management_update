<?php $__env->startSection('title'); ?>
Role List | <?php echo e($ins_name); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-flex align-items-center justify-content-between">
            <h4 class="mb-0">Role  List</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    
                    <li class="breadcrumb-item active"></li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->
<div class="row">
                        <div class="col-sm-6">
                            <div class="float-right d-md-block">
                                <div class="dropdown">
                                  <?php if(Auth::guard('admin')->user()->can('role.create')): ?>
                                   <a href="<?php echo e(route('admin.roles.create')); ?>" type="button"  class="btn btn-raised btn-primary waves-effect  btn-sm" >Add New Role</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                    <!-- end page title -->

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <?php echo $__env->make('flash_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="table-responsive">
                                    <table id="datatable-buttons" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                            <tr>
                                               <th>sl</th>
                                    <th>Role Name</th>
                                    <th >Permission List</th>
                                    <th>Action</th>
                                            </tr>
                                        </thead>


                                        <tbody>
                                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                   <td>

                                    <?php echo e($loop->index+1); ?>


                                    <td><?php echo e($role->name); ?></td>
                                    <td >
                                        <div class="row">


                                        <?php $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-1">
                                            <span class="badge bg-success mt-1">
                                               <?php echo e($perm->name); ?><br>
                                            </span>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    </td>

                                                <td>
                                                    <div class="btn-group">

<?php if(Auth::guard('admin')->user()->can('admin.edit')): ?>

                                                        <a href="<?php echo e(route('admin.roles.edit',$role->id)); ?>" type="button" class="btn btn-primary waves-light waves-effect  btn-sm"><i class="fas fa-pencil-alt"></i></a>
<?php endif; ?>
<?php if(Auth::guard('admin')->user()->can('admin.delete')): ?>


<?php if($role->id == 13): ?>


<?php else: ?>

                                                        <button type="button" class="btn btn-primary waves-light waves-effect  btn-sm" onclick="deleteTag(<?php echo e($role->id); ?>)"><i class="far fa-trash-alt"></i></button>

 <form id="delete-form-<?php echo e($role->id); ?>" action="<?php echo e(route('admin.roles.delete',$role->id)); ?>" method="POST" style="display: none;">
  <?php echo method_field('DELETE'); ?>
                                                    <?php echo csrf_field(); ?>

                                                </form>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                                    </div>
                                                </td>
                                            </tr>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        </tbody>
                                    </table>
</div>
                                </div>
                            </div>
                        </div> <!-- end col -->
                    </div> <!-- end row -->







<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

     <script>
         /**
         * Check all the permissions
         */
         $("#checkPermissionAll").click(function(){
             if($(this).is(':checked')){
                 // check all the checkbox
                 $('input[type=checkbox]').prop('checked', true);
             }else{
                 // un check all the checkbox
                 $('input[type=checkbox]').prop('checked', false);
             }
         });
         function checkPermissionByGroup(className, checkThis){
            const groupIdName = $("#"+checkThis.id);
            const classCheckBox = $('.'+className+' input');
            if(groupIdName.is(':checked')){
                 classCheckBox.prop('checked', true);
             }else{
                 classCheckBox.prop('checked', false);
             }
         }
     </script>

<script type="text/javascript">
    function deleteTag(id) {
        swal({
            title: 'Are you sure?',
            text: "You will not be able to revert this!",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'No, cancel!',
            confirmButtonClass: 'btn btn-success',
            cancelButtonClass: 'btn btn-danger',
            buttonsStyling: false,
            reverseButtons: true
        }).then((result) => {
            if (result.value) {
                event.preventDefault();
                document.getElementById('delete-form-'+id).submit();
            } else if (
                // Read more about handling dismissals
                result.dismiss === swal.DismissReason.cancel
            ) {
                swal(
                    'Cancelled',
                    'Your data is safe :)',
                    'error'
                )
            }
        })
    }
</script>
<?php $__env->stopSection(); ?>













<?php echo $__env->make('backend.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project_july_2022\htdocs\store_management_backend_2022_october\resources\views/backend/roles/index.blade.php ENDPATH**/ ?>